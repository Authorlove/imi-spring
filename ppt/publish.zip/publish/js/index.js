var video = document.getElementsByTagName('video');

function mv1(){
	video[0].play();
	video[1].play();
}
function mv1_end(){
	video[0].pause();
	video[1].pause();
}
function mv2(){
	video[2].play();
}
function mv2_end(){
	video[2].pause();
}
function mv3(){
	video[3].play();
}
function mv3_end(){
	video[3].pause();
}
function mv4(){
	video[4].play();
	video[5].play();
}
function mv4_end(){
	video[4].pause();
	video[5].pause();
}
function mv5(){
	video[6].play();
	video[6].play();
}
function mv5_end(){
	video[6].pause();
	video[6].pause();
}